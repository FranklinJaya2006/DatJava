package org.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class HibernateFullTest {

    private SessionFactory sessionFactory;

    @BeforeEach
    protected void setUp() throws Exception {
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
            .configure() // configures settings from hibernate.cfg.xml
            .build();
        try {
            sessionFactory = new MetadataSources(registry).buildMetadata().buildSessionFactory();
        } catch (Exception e) {
            StandardServiceRegistryBuilder.destroy(registry);
            throw e;
        }
    }

    @AfterEach
    protected void tearDown() throws Exception {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testBasicUsage() {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        User user1 = new User("John Doe", 25, "Computer Science");
        User user2 = new User("Jane Doe", 28, "Mathematics");
        session.save(user1);
        session.save(user2);
        session.getTransaction().commit();
        session.close();

        session = sessionFactory.openSession();
        session.beginTransaction();
        List<User> result = session.createQuery("from User", User.class).list();
        for (User user : result) {
            System.out.println("User (" + user.getName() + ") : " + user.getAge() + " years old, Major: " + user.getMajor());
        }
        session.getTransaction().commit();
        session.close();

        assertThat(result).hasSize(2);
        assertThat(result).extracting("name").containsExactlyInAnyOrder("John Doe", "Jane Doe");
    }

    @Test
    public void marco_is_in_the_house() {
        assertThat(1).isGreaterThanOrEqualTo(0);
    }
}
